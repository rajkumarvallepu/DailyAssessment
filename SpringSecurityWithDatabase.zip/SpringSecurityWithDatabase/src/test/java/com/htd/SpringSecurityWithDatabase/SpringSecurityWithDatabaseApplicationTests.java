package com.htd.SpringSecurityWithDatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityWithDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
